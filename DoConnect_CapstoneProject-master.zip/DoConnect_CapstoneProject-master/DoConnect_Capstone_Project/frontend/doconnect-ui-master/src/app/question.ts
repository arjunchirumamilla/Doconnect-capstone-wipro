export class Question {

  id:number=0
	question:string=''
  topic:string=''
	isApproved:boolean=false
  user:any
}
