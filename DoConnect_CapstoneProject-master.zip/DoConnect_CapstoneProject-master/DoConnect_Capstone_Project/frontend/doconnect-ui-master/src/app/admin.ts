export class Admin {

  id:number=0
	name:string=''
	password:string=''
  email:string=''
	phoneNumber:string=''
	isActive:boolean = true;

}
