export class MessageDTO{

  fromUser:string=''
  message:string=''
}

